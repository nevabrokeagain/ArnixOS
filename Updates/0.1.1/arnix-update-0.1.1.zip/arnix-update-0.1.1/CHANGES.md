## 0.1.1

- `sudo arnix upgrade` updates the whole system: arnix itself first (from the
  ArnixOS repo), then repo packages, AUR packages, flatpaks and snaps
- `sudo arnix self-update` updates only arnix; `arnix self-update FILE`
  installs an update archive; `arnix --version` shows the installed version
- updates carry one-time fixes for systems installed from older versions:
  every installed package is recorded in system.arnix, and GRUB's menu is
  created where early ISOs left a bare "grub>" prompt
- arnix's own packages are never looked up on the AUR or recorded as AUR packages
- the ArnixOS name, logo and wallpaper are now their own package
  (arnixos-branding), so arnix can be installed on other systems without
  renaming them
- new peak logo everywhere: boot menu, GRUB, wallpaper, login screen, fastfetch
- fastfetch shows system information next to the logo again
- installer: GRUB's menu is checked and retried, the whole install is verified
  before "Done", the bootloader disk must be a whole disk, and a log is kept
- every installed package is recorded in system.arnix (`arnix sync --record-only`)
- arnix leaves pacman.conf alone when the right repositories are already enabled
- builds work on systems whose gcc has no x86_64-linux-gnu-gcc (e.g. CachyOS)
- ISO build: works from a root-owned folder, checks the finished ISO, writes a
  .sha256 file, and refuses USB sticks and too little disk space

