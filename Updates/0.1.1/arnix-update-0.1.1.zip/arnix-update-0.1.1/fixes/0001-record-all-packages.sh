#!/bin/bash
# fix: record every installed package in system.arnix (older versions could miss some)
# Only writes the config, changes nothing else on the system.
set -euo pipefail
[[ -f /etc/arnix/arnix.conf && -f /etc/arnix/system.arnix ]] || exit 0
arnix sync --record-only
