#!/bin/bash
# fix: create GRUB's menu where it's missing (early ISOs could leave a bare "grub>" prompt)
# Only on ArnixOS systems that boot with GRUB; other systems' bootloaders are left alone.
set -euo pipefail
pacman -Qq arnixos-branding grub >/dev/null 2>&1 || exit 0
[[ -d /boot/grub ]] || exit 0
grep -q '^menuentry ' /boot/grub/grub.cfg 2>/dev/null && exit 0
grub-mkconfig -o /boot/grub/grub.cfg
grep -q '^menuentry ' /boot/grub/grub.cfg
