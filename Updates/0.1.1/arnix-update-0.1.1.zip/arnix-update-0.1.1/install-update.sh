#!/bin/bash
# install-update.sh: installs the arnix update in this folder.
#
#   sudo ./install-update.sh             install it
#   sudo ./install-update.sh --dry-run   only show what it would do
#   sudo ./install-update.sh --force     also install an older or the same version
#
# It works on every installed version of arnix, also those without
# 'arnix self-update', and on both kinds of install:
#   - ArnixOS (arnix is a pacman package): the packages are upgraded
#   - installed with setup.sh (plain files): arnix becomes a pacman package,
#     so later updates are ordinary package upgrades
# Your config in /etc/arnix and the packages listed in it are not touched.
#
# Afterwards it runs the one-time fixes in fixes/ that haven't run on this
# system yet (repairs for systems installed from older versions). Each fix
# that succeeds is remembered in /var/lib/arnix/fixes-applied and never runs
# again; one that fails is tried again with the next update.
set -euo pipefail
cd "$(dirname "$0")"

DRY=0
FORCE=0
for arg in "$@"; do
    case $arg in
        --dry-run) DRY=1 ;;
        --force) FORCE=1 ;;
        *) echo "unknown option $arg"; exit 1 ;;
    esac
done

die() { echo "install-update: error: $*" >&2; exit 1; }
step() { echo "==> $*"; }
run() {
    echo "  \$ $*"
    [[ $DRY == 1 ]] || "$@"
}

[[ $EUID -eq 0 || $DRY == 1 ]] || die "run it with sudo: sudo ./install-update.sh"
[[ -f VERSION && -d packages ]] || die "run it from inside the unpacked update folder"
NEW=$(<VERSION)

step "Checking the update's files"
sha256sum -c --quiet SHA256SUMS || die "the update's files are damaged, get the archive again"

# which arnix is installed, and how
if pacman -Qq arnix >/dev/null 2>&1; then
    kind=package
    OLD=$(pacman -Q arnix | awk '{print $2}')
    OLD=${OLD%-*}
elif [[ -x /usr/bin/arnix ]]; then
    kind=files
    OLD=$(sed -n 's/^ARNIX_VERSION = "\(.*\)"$/\1/p' /usr/bin/arnix)
    OLD=${OLD:-0.1.0}
else
    die "arnix isn't installed here; install it with setup.sh or the ArnixOS ISO first"
fi
echo "  installed: arnix $OLD ($([[ $kind == package ]] && echo "pacman package" || echo "installed with setup.sh"))"
echo "  update:    arnix $NEW"
if [[ $(vercmp "$NEW" "$OLD") -le 0 && $FORCE == 0 ]]; then
    die "arnix $OLD is already installed, which isn't older than $NEW (--force installs it anyway)"
fi

# the package manager always; the ArnixOS branding only where it's already there,
# so other systems (e.g. CachyOS) keep their own name
pkgs=(packages/arnix-[0-9]*.pkg.tar.zst)
[[ -f ${pkgs[0]} ]] || die "the arnix package is missing from packages/"
if pacman -Qq arnixos-branding >/dev/null 2>&1 ||
   [[ $(pacman -Qqo /usr/share/arnix/os-release 2>/dev/null) == arnix ]]; then
    branding=(packages/arnixos-branding-*.pkg.tar.zst)
    [[ -f ${branding[0]} ]] && pkgs+=("${branding[0]}")
fi

overwrite=()
reenable=()
if [[ $kind == files ]]; then
    step "Turning the setup.sh install into a pacman package"
    # the package brings the same files to /usr; the old copies would run twice
    for unit in arnix-rebuild.service arnix-killswitch.service; do
        if [[ -f /etc/systemd/system/$unit ]]; then
            if systemctl is-enabled --quiet "$unit" 2>/dev/null; then
                reenable+=("$unit")
                run systemctl disable "$unit"
            fi
            run rm -f "/etc/systemd/system/$unit"
        fi
    done
    for hook in arnix-installed.hook arnix-removed.hook; do
        [[ -f /etc/pacman.d/hooks/$hook ]] && run rm -f "/etc/pacman.d/hooks/$hook"
    done
    # files setup.sh put in place that now belong to the package
    overwrite=(--overwrite /usr/bin/arnix --overwrite /usr/bin/arnixconf --overwrite '/usr/share/arnix/*')
fi

step "Installing ${pkgs[*]##*/}"
run pacman -U --noconfirm "${overwrite[@]}" "${pkgs[@]}"

if [[ ${#reenable[@]} -gt 0 ]]; then
    run systemctl daemon-reload
    for unit in "${reenable[@]}"; do
        run systemctl enable "$unit"
    done
fi

# ArnixOS keeps a local copy of its packages, for reinstalling offline
if [[ -d /opt/arnix-repo ]]; then
    step "Updating the local repo in /opt/arnix-repo"
    run rm -f /opt/arnix-repo/arnix-[0-9]*.pkg.tar.zst /opt/arnix-repo/arnixos-branding-*.pkg.tar.zst
    run cp packages/*.pkg.tar.zst /opt/arnix-repo/
    run repo-add -q -R /opt/arnix-repo/arnix.db.tar.gz /opt/arnix-repo/*.pkg.tar.zst
fi

if [[ $DRY == 0 && -f /etc/arnix/arnix.conf ]]; then
    step "Checking your config with the new version"
    arnixconf check || echo "install-update: warning: fix the config with 'sudo arnixconf edit'"
fi

# ---- one-time fixes ----
FIXES_DONE=${ARNIX_STATE:-/var/lib/arnix}/fixes-applied
pending=()
for fix in fixes/*.sh; do
    [[ -f $fix ]] || continue
    id=$(basename "$fix" .sh)
    grep -qxF "$id" "$FIXES_DONE" 2>/dev/null || pending+=("$fix")
done
if [[ ${#pending[@]} -gt 0 ]]; then
    step "One-time fixes for this system"
    failed=0
    for fix in "${pending[@]}"; do
        id=$(basename "$fix" .sh)
        what=$(sed -n 's/^# fix: //p' "$fix" | head -n1)
        echo "  $id: ${what:-no description}"
        if [[ $DRY == 1 ]]; then
            continue
        fi
        if bash "$fix"; then
            mkdir -p "$(dirname "$FIXES_DONE")"
            echo "$id" >> "$FIXES_DONE"
        else
            failed=1
            echo "install-update: warning: fix $id failed, it's tried again with the next update"
        fi
    done
fi

step "Done"
[[ $DRY == 1 ]] && echo "dry run, nothing was changed" || echo "arnix $NEW is installed ($(arnix --version 2>/dev/null))"
