## 0.1.2

- a system.arnix that is still the example config (Plasma, VS Code, Spotify,
  Discord, hostname "arnix", timezone UTC) is no longer rebuilt from. Any
  `sudo arnix` command, the boot-time rebuild included, writes it from what is
  actually installed first; the old file stays available with `arnix rollback`.
  Before, a rebuild installed the example's apps and removed everything it
  didn't list
- the same goes for the example with packages added to it by the pacman hooks
- install-update.sh also installs arnix where it isn't installed (e.g. after
  removing it), and writes system.arnix from the system when there is none
- updates carry a one-time fix that writes system.arnix from the system where
  it is missing or still the example
