arnix update 0.1.2

With arnix 0.1.1 or newer:
    sudo arnix self-update arnix-update-0.1.2.tar.gz

With any version (also 0.1.0), from inside this folder:
    sudo ./install-update.sh

What changed: CHANGES.md
