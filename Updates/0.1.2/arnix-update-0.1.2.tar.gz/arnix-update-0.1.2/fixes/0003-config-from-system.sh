#!/bin/bash
# fix: write system.arnix from this system where it is missing or still the example config
# Only writes the config, changes nothing else on the system.
set -euo pipefail
command -v arnix >/dev/null || exit 0
# with no config this writes one from what is installed; with the example config
# arnix 0.1.2 replaces it first; otherwise it records anything that's missing
arnix sync --record-only
